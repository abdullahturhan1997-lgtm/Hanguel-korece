package com.hangeul.korece;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Standalone Android wrapper for the offline HANGEUL learning app. */
public class MainActivity extends Activity {
    private static final int REQUEST_SAVE = 501;
    private static final int REQUEST_PICK = 502;
    private static final String HOME = "file:///android_asset/index.html";
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingBackup;
    private ValueCallback<Uri[]> filePicker;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 16, 32));
        getWindow().setNavigationBarColor(Color.rgb(11, 16, 32));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 16, 32));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // XP and progress stored between app launches
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setAllowFileAccess(true); // For bundled asset HTML
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowContentAccess(true); // For JSON backup import
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // JavaScript bridge is safe only because external pages cannot open in this WebView.
        webView.addJavascriptInterface(new AppBridge(), "HangeulAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return externalLink(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return externalLink(Uri.parse(url));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePicker != null) filePicker.onReceiveValue(null);
                filePicker = callback;
                try {
                    startActivityForResult(params.createIntent(), REQUEST_PICK);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    filePicker = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Dosya seçici açılamadı", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                int result = tts.setLanguage(Locale.KOREAN);
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                        && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        setContentView(webView);
        webView.loadUrl(HOME);
    }

    private boolean externalLink(Uri url) {
        if (url == null) return true;
        String s = url.toString();
        if (s.startsWith("file:///android_asset/") || s.startsWith("about:blank")) return false;
        if ("https".equals(url.getScheme()) || "http".equals(url.getScheme())) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, url)); }
            catch (Exception ex) { Toast.makeText(this, "Bağlantı açılamadı", Toast.LENGTH_SHORT).show(); }
        }
        return true;
    }

    private class AppBridge {
        @JavascriptInterface
        public void speak(String korean) {
            runOnUiThread(() -> {
                if (ttsReady && tts != null) {
                    tts.setSpeechRate(0.8f);
                    tts.speak(korean, TextToSpeech.QUEUE_FLUSH, null, "korean-word");
                } else {
                    Toast.makeText(MainActivity.this,
                            "Telefonunda Korece ses paketi gerekli olabilir", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface
        public void saveTextFile(String filename, String content, String mime) {
            runOnUiThread(() -> {
                pendingBackup = content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                try { startActivityForResult(intent, REQUEST_SAVE); }
                catch (ActivityNotFoundException ex) {
                    Toast.makeText(MainActivity.this, "Dosya kaydetme ekranı açılamadı", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == REQUEST_PICK && filePicker != null) {
            filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, intent));
            filePicker = null;
        }
        if (requestCode == REQUEST_SAVE) {
            if (resultCode == RESULT_OK && intent != null && intent.getData() != null && pendingBackup != null) {
                try (OutputStream out = getContentResolver().openOutputStream(intent.getData())) {
                    if (out == null) throw new IllegalStateException("Dosya yazma izni alınamadı");
                    out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Yedek kaydedildi", Toast.LENGTH_SHORT).show();
                } catch (Exception ex) {
                    Toast.makeText(this, "Yedek kaydedilemedi", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackup = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
